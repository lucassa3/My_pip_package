#!/usr/bin/env python3i
import my_hello

my_hello.world()